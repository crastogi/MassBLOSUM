#include <Rcpp.h>
using namespace Rcpp;
using namespace std;

class MassBLOSUM{
public:
  MassBLOSUM(double, double);
  double multiply();
private:
  double x;
  double y;
};

MassBLOSUM::MassBLOSUM(double xIN, double yIN) {
  x = xIN;
  y = yIN;
}

double MassBLOSUM::multiply() {
  return(x*y);
}

RCPP_MODULE(massblosummodule){
  Rcpp::class_<MassBLOSUM>( "MassBLOSUM" )
  .constructor<double, double>("documentation for default constructor")
  .method( "multiply", &MassBLOSUM::multiply, "Alternative method for setting the affinity floor")
  ;
}
